/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;
import java.util.List;
import DAOdataGame.dataGameDAO;
import DAOimplement.dataGameimplement;
import model.*;
import javax.swing.JOptionPane;
import view.TokoView;
import view.PemilihanKarakterView;
/**
 *
 * @author alfi
 */
public class Toko {
    TokoView frame;
    
    dataGameimplement impldatagame;
    List<dataGame> dg;
    dataGame ds;
    dataGame s;
    
    public Toko(TokoView frame){
        this.frame = frame;
        impldatagame = new dataGameDAO();
        ds = new dataGame();
        s = new dataGame();
        dg = impldatagame.getSenjata();
        
    }
    public void isitabel(){
        dg = impldatagame.getSenjata();
        TabelSenjata mp = new TabelSenjata(dg);
        frame.getTabelDataSenjata().setModel(mp);
    }
    
    
    
    public void gacha(){
        int angkarandom = (int) (Math.random() * 100) + 1;
        if (angkarandom <= 70){
            ds.setSenjata("Pedang Biasa");
            
        }else if(angkarandom > 70 && angkarandom <= 90 ){
            ds.setSenjata("Pedang Diamond");
            
        }else{
            ds.setSenjata("Pedang Dewa");
            
        }
        int response = JOptionPane.showConfirmDialog(null, "Kamu Mendapatkan " + ds.getSenjata() + " Apakah Kamu Ingin Mengganti Senjatamu?", "Confirm", JOptionPane.YES_NO_OPTION);

            
            if (response == JOptionPane.YES_OPTION) {
                
                s.setSenjata(ds.getSenjata());
                s.setId_karakter(frame.getId());
                impldatagame.gantiSenjata(s);
            } else if (response == JOptionPane.NO_OPTION) {
                
                s.setSenjata(frame.dg.getSenjata());
                s.setId_karakter(frame.getId());
                impldatagame.gantiSenjata(s);
            } else if (response == JOptionPane.CLOSED_OPTION) {
                
                s.setSenjata(frame.dg.getSenjata());
                s.setId_karakter(frame.getId());
                impldatagame.gantiSenjata(s);
            }
    }
    public void kuringingold(){
        ds.setGold(frame.dg.getGold() - 100);
        ds.setGold(ds.getGold());
        ds.setId_karakter(frame.getId());
        impldatagame.kuranginGold(ds);
        frame.getjTextgold().setText(Integer.toString(ds.getGold()));
        frame.dg.setGold(frame.dg.getGold()-100);
        frame.dg.setSenjata(s.getSenjata());
    }
    
}

