/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;
import DAOdataGame.dataGameDAO;
import DAOimplement.dataGameimplement;
import model.*;
import view.BattleView;
/**
 *
 * @author alfi
 */
public class Battle {
    BattleView frame;
    dataGameimplement impldatagame;
    public dataGame dg;
    
    public Battle(BattleView frame){
        dg = new dataGame();
        this.frame = frame;
        impldatagame = new dataGameDAO();
    }
    
    public void selesaibattle(){
        if (frame.p.getLevel()==1){
            dg.setLevel(frame.p.getLevel() + 1);
            dg.setDarah(frame.p.getDarah() + 1000);
            dg.setDaya_serang(frame.p.getDaya_serang()+ 100);
        }else if (frame.p.getLevel()==2){
            dg.setLevel(frame.p.getLevel() + 1);
            dg.setDarah(frame.p.getDarah() + 2000);
            dg.setDaya_serang(frame.p.getDaya_serang()+ 200);
        }else{
            dg.setLevel(frame.p.getLevel());
            dg.setDarah(frame.p.getDarah());
            dg.setDaya_serang(frame.p.getDaya_serang());
        }
        dg.setGold(frame.p.getGold() + 100);
        dg.setGold(dg.getGold());
        dg.setId_karakter(frame.getId());
        impldatagame.selesaibattle(dg);
    }
}
