/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.util.List;
import DAOdataGame.dataGameDAO;
import DAOimplement.dataGameimplement;
import model.*;
import view.BattleView;
import view.PemilihanLevel;
import view.TokoView;

/**
 *
 * @author alfi
 */
public class PilihNPC {
    PemilihanLevel frame;
    dataGameimplement impldatagame;
    List<dataGame> dg;
    
    public PilihNPC(PemilihanLevel frame){
        this.frame = frame;
        impldatagame = new dataGameDAO();
        
    }
    
    public void setNPC(){
        int id_npc = frame.getIdnpc();
        List<dataGame> dg = impldatagame.getAllnpc(id_npc);
        dataGame dn = dg.get(0);
        BattleView b = new BattleView(frame.p, dn);
        b.setVisible(true);
        b.setLocationRelativeTo(null);
    }
    
    public void pergiketoko(){
        TokoView b = new TokoView(frame.p);
        b.setVisible(true);
        b.setLocationRelativeTo(null);
    }
}
