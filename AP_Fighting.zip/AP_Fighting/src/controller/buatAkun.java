/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;
import java.util.List;
import DAOdataGame.dataGameDAO;
import DAOimplement.dataGameimplement;
import javax.swing.JOptionPane;
import model.*;
import view.buatAkunView;
/**
 *
 * @author alfi
 */
public class buatAkun {
    buatAkunView frame;
    dataGameimplement impldatagame;
    List<dataGame> dg;
    public buatAkun(buatAkunView frame){
        this.frame = frame;
        impldatagame = new dataGameDAO();
    }
    public void insert(){
        dataGame da = new dataGame();
        da.setNamaAkun(frame.getjTextBUsername().getText());
        da.setPassword(frame.getjTextBPassword().getText());
        impldatagame.buatAkun(da);
        
    }
}
