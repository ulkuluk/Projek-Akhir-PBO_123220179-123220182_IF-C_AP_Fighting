/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;
import java.util.List;
import DAOdataGame.dataGameDAO;
import DAOimplement.dataGameimplement;
import javax.swing.JOptionPane;
import model.*;
import view.PemilihanKarakterView;
import view.login;
/**
 *
 * @author alfi
 */
public class cekAkun {
    login frame;
    dataGameimplement impldatagame;
    List<dataGame> dg;
    public dataGame da;
    public cekAkun(login frame){
        this.frame = frame;
        impldatagame = new dataGameDAO();
    }
    public void Akun(){
        String username = frame.getjTextUsername().getText();
        char[] passwordcek = frame.getjPassword().getPassword();
        String password = new String(passwordcek);
        List<dataGame> dg = impldatagame.getAkun(username);
        
        if (dg != null && !dg.isEmpty()) {
            da = dg.get(0);
            if(password.equals(da.getPassword())){ 
                PemilihanKarakterView v = new PemilihanKarakterView(da);
                v.setVisible(true);
                v.setLocationRelativeTo(null);
                 
            }else{
                JOptionPane.showMessageDialog(frame, "Akun Tidak Ditemukan Atau Password Salah!", "Message", JOptionPane.ERROR_MESSAGE);
            }
        }else {
            JOptionPane.showMessageDialog(frame, "Akun Tidak Ditemukan Atau Password Salah!", "Message", JOptionPane.ERROR_MESSAGE);   
        }      
    }
    
}
