/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import java.util.List;
import DAOdataGame.dataGameDAO;
import DAOimplement.dataGameimplement;
import model.*;
import view.PemilihanKarakterView;


/**
 *
 * @author alfi
 */
public class dataGamecontroller {
    PemilihanKarakterView frame;
    dataGameimplement impldatagame;
    List<dataGame> dg;
    String akun;
    
    public dataGamecontroller(PemilihanKarakterView frame){
        this.frame = frame;
        impldatagame = new dataGameDAO();
        this.akun = frame.getAkun();
        dg = impldatagame.getAll(akun);
    }
    public void isitabel(){
        dg = impldatagame.getAll(akun);
        TabelKarakter tabelkarakter = new TabelKarakter(dg);
        frame.getTabelKarakter().setModel(tabelkarakter);
    }
    
    public void insert(){
        dataGame dk = new dataGame();
        dk.setNama(frame.getjTextKarakterBaru().getText());
        dk.setLevel(1);
        dk.setDaya_serang(100);
        dk.setDarah(1000);
        dk.setGold(0);
        dk.setSenjata("Tangan Kosong");
        dk.setNamaAkun(frame.getAkun());
        impldatagame.tambahKarakter(dk);
        
    }
    public void delete(){
        int id_karakter = (frame.p.getId_karakter());
        impldatagame.delete(id_karakter);
    }
    
}
