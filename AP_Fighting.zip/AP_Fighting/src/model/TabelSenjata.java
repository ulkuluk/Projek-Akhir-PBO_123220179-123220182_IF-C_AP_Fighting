/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;
import java.util.List;
import javax.swing.table.AbstractTableModel;
/**
 *
 * @author alfi
 */
public class TabelSenjata extends AbstractTableModel{
    List<dataGame> dg;
    public TabelSenjata(List<dataGame>dg){
        this.dg = dg;
    }
    
    @Override
    public int getRowCount() {
        return dg.size();
    }

    @Override
    public int getColumnCount() {
        return 3;
    }
    
    @Override
    public String getColumnName(int column){
        switch(column){
            case 0:
                return "Nama Senjata";
            case 1:
                return "Penmbahan Daya Serang";
            case 2:
                return "Rarity";
            
            default:
                return null;
        }
    }

    @Override
    public Object getValueAt(int row, int column) {
        switch(column){
            case 0:
                return dg.get(row).getNama();
            case 1:
                return dg.get(row).getDaya_serang();
            case 2:
                return dg.get(row).getRarity();
            
            default:
                return null;
        }
    }
}
