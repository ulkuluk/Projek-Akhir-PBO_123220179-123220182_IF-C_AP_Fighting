/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;
import java.util.List;
import javax.swing.table.AbstractTableModel;
/**
 *
 * @author alfi
 */
public class TabelKarakter extends AbstractTableModel{
    List<dataGame> dg;
    public TabelKarakter(List<dataGame>dg){
        this.dg = dg;
    }
    
    @Override
    public int getRowCount() {
        return dg.size();
    }

    @Override
    public int getColumnCount() {
        return 7;
    }
    
    @Override
    public String getColumnName(int column){
        switch(column){
            case 0:
                return "ID Karakter";
            case 1:
                return "Nama Karakter";
            case 2:
                return "Level";
            case 3:
                return "Daya Serang";
            case 4:
                return "Darah";
            case 5:
                return "Gold";
            case 6:
                return "Senjata";
            default:
                return null;
        }
    }

    @Override
    public Object getValueAt(int row, int column) {
        switch(column){
            case 0:
                return dg.get(row).getId_karakter();
            case 1:
                return dg.get(row).getNama();
            case 2:
                return dg.get(row).getLevel();
            case 3:
                return dg.get(row).getDaya_serang();
            case 4:
                return dg.get(row).getDarah();
            case 5:
                return dg.get(row).getGold();
            case 6:
                return dg.get(row).getSenjata();
            default:
                return null;
        }
    }
}
