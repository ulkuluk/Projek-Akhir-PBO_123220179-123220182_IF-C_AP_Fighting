/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author alfi
 */
public class dataGame {
    int id_karakter, id_npc;
    int darah, daya_serang, level, gold;
    String nama, namaakun, password,senjata;
    private String rarity;

    public int getId_karakter() {
        return id_karakter;
    }

    public void setId_karakter(int id_karakter) {
        this.id_karakter = id_karakter;
    }

    public int getId_npc() {
        return id_npc;
    }

    public void setId_npc(int id_npc) {
        this.id_npc = id_npc;
    }

    public int getDarah() {
        return darah;
    }

    public void setDarah(int darah) {
        this.darah = darah;
    }

    public int getDaya_serang() {
        return daya_serang;
    }

    public void setDaya_serang(int daya_serang) {
        this.daya_serang = daya_serang;
    }

    public int getLevel() {
        return level;
    }

    public void setLevel(int level) {
        this.level = level;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getNamaAkun() {
        return namaakun;
    }

    public void setNamaAkun(String namaakun) {
        this.namaakun = namaakun;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    public int getGold() {
        return gold;
    }

    public void setGold(int gold) {
        this.gold = gold;
    }

    public String getSenjata() {
        return senjata;
    }

    public void setSenjata(String senjata) {
        this.senjata = senjata;
    }

    /**
     * @return the rarity
     */
    public String getRarity() {
        return rarity;
    }

    /**
     * @param rarity the rarity to set
     */
    public void setRarity(String rarity) {
        this.rarity = rarity;
    }
    
}
