/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAOimplement;
import java.util.List;
import model.*;
/**
 *
 * @author alfi
 */
public interface dataGameimplement {
    public void menyerang(dataGame d);
    public void buatAkun(dataGame d);
    public void tambahKarakter(dataGame d);
    public List<dataGame> getAll(String akun);
    public List<dataGame> getAllnpc(int id_npc);
    public List<dataGame> getAkun(String username);
    public List<dataGame> getSenjata();
    public void gantiSenjata(dataGame d);
    public void selesaibattle(dataGame d);
    public void kuranginGold(dataGame d);
    public void delete(int id_karakter);
    
}
