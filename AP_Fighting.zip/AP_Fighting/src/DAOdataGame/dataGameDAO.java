/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAOdataGame;
import koneksi.connector;
import model.*;
import DAOimplement.dataGameimplement;
import java.sql.*;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.List;
/**
 *
 * @author alfi
 */
public class dataGameDAO implements dataGameimplement{
    
    Connection  connection;
    
    final String select = "SELECT * FROM karakter where Akun=?;";
    final String insertakun = "INSERT INTO akun (Username, Password) VALUES (?, ?)";
    final String insertkarakter = "INSERT INTO karakter (Nama, Level, Daya_Serang, Darah, Gold, Senjata, Akun) VALUES (?, ?, ?, ?, ?, ?, ?)";
    final String selectnpc = "SELECT * FROM npc where id_npc=?;";
    final String selectakun = "SELECT * FROM akun where Username=?";
    final String selectsenjata = "SELECT * FROM senjata";
    final String updatesenjata = "update karakter set Senjata=? where id_karakter=?";
    final String updategold = "update karakter set Level=?, Daya_Serang=?, Darah=?, Gold=? where id_karakter=?";
    final String kurangingold = "update karakter set Gold=? where id_karakter=?";
    final String delete = "delete from karakter where id_karakter=?";
    
    public dataGameDAO(){
        connection = connector.connection();
    }
    
    @Override
    public void menyerang (dataGame d){
        
    }
    
    @Override
    public void buatAkun(dataGame d){
        PreparedStatement statement = null;
        try{
            statement = connection.prepareStatement(insertakun, Statement.RETURN_GENERATED_KEYS);
            statement.setString(1, d.getNamaAkun());
            statement.setString(2,d.getPassword());
            statement.executeUpdate();
        }catch(SQLException ex){
            ex.printStackTrace();
        }finally{
            try{
                statement.close();
            }catch(SQLException ex){
                ex.printStackTrace();
            }
        }
    }
    
    @Override
    public void tambahKarakter(dataGame d){
        PreparedStatement statement = null;
        try{
            statement = connection.prepareStatement(insertkarakter, Statement.RETURN_GENERATED_KEYS);
            statement.setString(1,d.getNama());
            statement.setInt(2,d.getLevel());
            statement.setInt(3,d.getDaya_serang());
            statement.setInt(4,d.getDarah());
            statement.setInt(5,d.getGold());
            statement.setString(6,d.getSenjata());
            statement.setString(7,d.getNamaAkun());
            statement.executeUpdate();
        }catch(SQLException ex){
            ex.printStackTrace();
        }finally{
            try{
                statement.close();
            }catch(SQLException ex){
                ex.printStackTrace();
            }
        }
    }
    
    @Override
    public List<dataGame> getAll(String akun) {
        List<dataGame> dg = null;
        try{
            dg = new ArrayList<dataGame>();
            PreparedStatement ps = connection.prepareStatement(select);
            ps.setString(1, akun);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                dataGame game = new dataGame();
                game.setId_karakter(rs.getInt("id_karakter"));
                game.setNama(rs.getString("Nama"));
                game.setLevel(rs.getInt("Level"));
                game.setDaya_serang(rs.getInt("Daya_Serang"));
                game.setDarah(rs.getInt("Darah"));
                game.setGold(rs.getInt("Gold"));
                game.setSenjata(rs.getString("Senjata"));
                game.setNamaAkun("akun");
                dg.add(game);
                
            }
        }catch(SQLException ex){
            Logger.getLogger(dataGameDAO.class.getName()).log(Level.SEVERE, null,ex);
        }
        
        return dg;
    }
    @Override
    public List<dataGame> getAllnpc(int id_npc) {
        List<dataGame> dg = null;
        try{
            dg = new ArrayList<dataGame>();
            PreparedStatement ps = connection.prepareStatement(selectnpc);
            ps.setInt(1, id_npc);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                dataGame game = new dataGame();
                game.setId_npc(rs.getInt("id_npc"));
                game.setNama(rs.getString("Nama"));
                game.setDaya_serang(rs.getInt("Daya_Serang"));
                game.setDarah(rs.getInt("Darah"));
                dg.add(game);
                
            }
        }catch(SQLException ex){
            Logger.getLogger(dataGameDAO.class.getName()).log(Level.SEVERE, null,ex);
        }
        
        return dg;
    }
    @Override
    public List<dataGame> getAkun(String username){
        List<dataGame> dg = null;
        try{
            dg = new ArrayList<dataGame>();
            PreparedStatement ps = connection.prepareStatement(selectakun);
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                dataGame game = new dataGame();
                game.setNamaAkun(rs.getString("Username"));
                game.setPassword(rs.getString("Password"));
                dg.add(game);
                
            }
        }catch(SQLException ex){
            Logger.getLogger(dataGameDAO.class.getName()).log(Level.SEVERE, null,ex);
        }
        return dg;
    }
    @Override
    public List<dataGame> getSenjata() {
        List<dataGame> dg = null;
        try{
            dg = new ArrayList<dataGame>();
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(selectsenjata);
            while(rs.next()){
                dataGame game = new dataGame();
                game.setNama(rs.getString("nama_senjata"));
                game.setDaya_serang(rs.getInt("daya_serang"));
                game.setRarity(rs.getString("rarity"));
                dg.add(game);
                
            }
        }catch(SQLException ex){
            Logger.getLogger(dataGameDAO.class.getName()).log(Level.SEVERE, null,ex);
        }
        
        return dg;
    }
    @Override
    public void gantiSenjata(dataGame d){
        PreparedStatement statement = null;
        try{
            statement = connection.prepareStatement(updatesenjata, Statement.RETURN_GENERATED_KEYS);
            statement.setString(1,d.getSenjata());
            statement.setInt(2,d.getId_karakter());
            statement.executeUpdate();
        }catch(SQLException ex){
            ex.printStackTrace();
        }finally{
            try{
                statement.close();
            }catch(SQLException ex){
                ex.printStackTrace();
            }
        }
    }
    @Override
    public void selesaibattle(dataGame d){
        PreparedStatement statement = null;
        try{
            statement = connection.prepareStatement(updategold, Statement.RETURN_GENERATED_KEYS);
            statement.setInt(1,d.getLevel());
            statement.setInt(2,d.getDaya_serang());
            statement.setInt(3,d.getDarah());
            statement.setInt(4,d.getGold());
            statement.setInt(5,d.getId_karakter());
            statement.executeUpdate();
        }catch(SQLException ex){
            ex.printStackTrace();
        }finally{
            try{
                statement.close();
            }catch(SQLException ex){
                ex.printStackTrace();
            }
        }
    }
    @Override
    public void kuranginGold(dataGame d){
        PreparedStatement statement = null;
        try{
            statement = connection.prepareStatement(kurangingold, Statement.RETURN_GENERATED_KEYS);
            
            statement.setInt(1,d.getGold());
            statement.setInt(2,d.getId_karakter());
            statement.executeUpdate();
        }catch(SQLException ex){
            ex.printStackTrace();
        }finally{
            try{
                statement.close();
            }catch(SQLException ex){
                ex.printStackTrace();
            }
        }
    }
    @Override
    public void delete(int id_karakter) {
        PreparedStatement statement = null;
        try{
            statement = connection.prepareStatement(delete);
            statement.setInt(1, id_karakter);
            statement.executeUpdate();
        }catch(SQLException ex){
            ex.printStackTrace();
        }finally{
            try{
                statement.close();
            }catch(SQLException ex ){
                ex.printStackTrace();
            }
        }
    }
}
